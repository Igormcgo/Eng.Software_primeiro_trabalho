var indexSectionsWithContent =
{
  0: "abcefglmrsu~",
  1: "eflms",
  2: "fmsu",
  3: "abcefglmrs~",
  4: "fs",
  5: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "typedefs",
  5: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Typedefs",
  5: "Macros"
};

