var searchData=
[
  ['getdestiny_0',['getDestiny',['../class_flow.html#a00922e19b22e8909ee426deadc31d42e',1,'Flow']]],
  ['getname_1',['getName',['../class_flow.html#a9c00ce3eed7cb2cccddad17be0613003',1,'Flow::getName()'],['../class_system.html#aa9491c5156df3ce128fb773ef3b13eec',1,'System::getName()']]],
  ['getorigin_2',['getOrigin',['../class_flow.html#aefea66e1f8c995f50f59eae670094940',1,'Flow']]],
  ['getvalue_3',['getValue',['../class_system.html#a6ffc74bae81548cf4329e9b5977bc154',1,'System']]]
];
