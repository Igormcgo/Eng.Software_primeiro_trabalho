#ifndef MODEL_INTERFACE
#define MODEL_INTERFACE

#include "flow_interface.h"
#include <iterator>
#include <vector>
class ModelInterface{
    public:
        typedef vector<SystemInterface*>::iterator systemIterator;
        typedef vector<FlowInterface*>::iterator flowIterator;
        virtual void run(double, double, double) = 0;
        virtual void add(SystemInterface*) = 0;
        virtual void add(FlowInterface*) = 0;
        virtual systemIterator beginSystem() = 0;
        virtual systemIterator endSystem() = 0;
        virtual flowIterator beginFlow() = 0;
        virtual flowIterator endFlow() = 0;
};
#endif