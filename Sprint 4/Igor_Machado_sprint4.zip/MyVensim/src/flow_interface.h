#ifndef FLOW_INTERFACE
#define FLOW_INTERFACE

#include "system_interface.h"
#include <string>
using namespace std;

class FlowInterface{
    public:
        virtual void setOrigin(SystemInterface*) = 0;
        virtual void setDestiny(SystemInterface*) = 0;
        virtual void setName(string) = 0;
        virtual SystemInterface* getOrigin(void) const = 0;
        virtual SystemInterface* getDestiny(void) const = 0;
        virtual string getName(void) const = 0;
        virtual void clearOrigin(void) = 0;
        virtual void clearDestiny(void) = 0;
        virtual double execute() = 0;
};

#endif