#ifndef FLOW
#define FLOW
#include "flow_interface.h"

class Flow : public FlowInterface{
    public:
        /**
         * @brief Construct a new Flow object
         * 
         */
        Flow();
        
        /**
         * @brief Construct a new Flow object
         * @param name Name for system
         * @param origin The Flow's origin
         * @param destiny The Flow's destiny
         */
        Flow(string, SystemInterface*, SystemInterface*);
        
        /**
         * @brief Destroy the Flow object
         * 
         */
        virtual ~Flow();
        
        /**
         * @brief Set the Origin Flow
         * 
         * @param origin The Flow's origin
         */
        void setOrigin(SystemInterface* origin);
        
        /**
         * @brief Set the Destiny Flow
         * 
         * @param destiny The Flow's destiny
         */
        void setDestiny(SystemInterface* destiny);
        
        /**
         * @brief Set the Name Flow
         * 
         * @param name The Flow's name
         */
        void setName(string name);
        
        /**
         * @brief Get the Flow origin
         * 
         * @return System* : The Flow's origin
         */
        SystemInterface* getOrigin(void) const;
        
        /**
         * @brief Get the Flow destiny
         * 
         * @return System* : The Flow's destiny
         */
        SystemInterface* getDestiny(void) const;
        
        /**
         * @brief Get the Flow name
         * 
         * @return string : Name from the Flow
         */
        string getName(void) const;
        
        /**
         * @brief Clear the Flow origin
         * 
         */
        void clearOrigin(void);
        
        /**
         * @brief Clear the Flow destiny
         * 
         */
        void clearDestiny(void);
        
        /**
         * @brief Purely virtual method that calculates the Flow value 
         * 
         * @return double : The Flow's value
         */
        virtual double execute() = 0;

    private:
        //attributes
        SystemInterface* origin;
        SystemInterface* destiny;
        string name;

        /**
         * @brief Construct a new Flow object by copy
         * 
         * @param flow Object to be copied
         */
        Flow(const Flow& flow);
        
        /**
         * @brief Overload of the equal operator
         * 
         * @param flow 
         * @return Flow& 
         */
        Flow& operator= (const Flow& flow);
};
#endif