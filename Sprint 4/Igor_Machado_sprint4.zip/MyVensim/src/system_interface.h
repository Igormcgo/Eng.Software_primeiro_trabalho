#ifndef SYSTEM_INTERFACE
#define SYSTEM_INTERFACE

#include <string>
using namespace std;

class SystemInterface{
    public:
        virtual void setValue(double) = 0;
        virtual void setName(string) = 0;
        virtual double getValue(void) const = 0;
        virtual string getName(void) const = 0;
};

#endif