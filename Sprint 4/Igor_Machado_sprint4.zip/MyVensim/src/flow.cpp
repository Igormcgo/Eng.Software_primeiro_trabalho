#include "flow.h"

//constructors and destructors
//public 
Flow::Flow(){}
Flow::Flow(string name, SystemInterface* origin, SystemInterface* destiny){
    this->name = name;
    this->origin = origin;
    this->destiny = destiny;
}
Flow::~Flow(){}

//getters and setters
void Flow::setOrigin(SystemInterface* origin){
    this->origin = origin;
}

void Flow::setDestiny(SystemInterface* destiny){
    this->destiny = destiny;
}

void Flow::setName(string name){
    this->name = name;
}

SystemInterface* Flow::getOrigin(void) const{
    return this->origin;
}

SystemInterface* Flow::getDestiny(void) const{
    return this->destiny;
}

string Flow::getName(void) const{
    return this->name;
}

void Flow::clearOrigin(void){
    this->origin = NULL;
}

void Flow::clearDestiny(void){
    this->destiny = NULL;
}

//private
Flow::Flow(const Flow& flow){
    this->origin = flow.getOrigin();
    this->destiny = flow.getDestiny();
    this->name = flow.getName();
}

Flow& Flow::operator= (const Flow& flow){
    if(this == &flow)
        return *this;
    
    this->origin = flow.getOrigin();
    this->destiny = flow.getDestiny();
    this->name = flow.getName();
    return *this;
}

