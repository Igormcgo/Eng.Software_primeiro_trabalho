#include "system.h"

//constructors and destructors
//public 
System::System(){
    value = 0;
}
System::System(double value, string name){
    this->name = name;
    this->value = value;
}
System::~System(){}

//getters and setters
void System::setValue(double value){
    this->value = value;
}
void System::setName(string name){
    this->name = name;
}
double System::getValue(void) const{
    return this->value;
}
string System::getName(void) const{
    return this->name;
}

//private
System::System(const System& sys){
    this->value = sys.getValue();
    this->name = sys.getName();
}

System& System::operator= (const System& sys){
    if(this == &sys)
        return *this;
    
    //verificacao
    this->name = sys.getName();
    this->value = sys.getValue();
    return *this;
}