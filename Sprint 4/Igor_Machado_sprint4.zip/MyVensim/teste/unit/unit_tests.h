#ifndef UNIT_TESTS
#define UNIT_TESTS
        void run_unit_tests_globals( void );
#endif