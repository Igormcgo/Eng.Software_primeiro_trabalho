#ifndef UNIT_FLOW
#define UNIT_FLOW
        void unit_Flow_constructor( void);
        void unit_Flow_destructor( void);
        void unit_Flow_setOrigin( void);
        void unit_Flow_getOrigin( void);
        void unit_Flow_setDestiny( void);
        void unit_Flow_getDestiny( void);
        void unit_Flow_getName( void);
        void unit_Flow_setName( void );
        void unit_Flow_clearDestiny( void);
        void unit_Flow_clearOrigin( void);
        void unit_Flow_execute( void);
        void run_unit_tests_Flow( void );
#endif