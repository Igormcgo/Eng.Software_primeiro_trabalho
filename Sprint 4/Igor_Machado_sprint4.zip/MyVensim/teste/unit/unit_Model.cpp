#include "unit_Model.h"
#include <assert.h>
#include <cmath>
#include "..\..\src\flow.h"
#include "..\..\src\system.h"
#include "..\..\src\model.h"

class ExponentialFlow : public Flow{
    public:
        ExponentialFlow(string nome, SystemInterface* origin, SystemInterface* destiny) : Flow(nome, origin, destiny){}
        virtual double execute(){
            return 0.01 * getOrigin()->getValue();
        }
};

void unit_Model_constructor( void){}
void unit_Model_destructor( void){}

//Usando um teste funcional como o exponencial para dar realizar a verificacao do metodo run
void unit_Model_run( void){
    System s1(100, "s1");
    System pop2(0, "pop2");

    ExponentialFlow f1("f1", &s1, &pop2);

    Model model1;
    model1.add(&s1);
    model1.add(&pop2);
    model1.add(&f1);

    model1.run(0, 100, 1);

    assert(fabs(round((s1.getValue() - 36.6032)*10000)) < 1);
    assert(fabs(round((pop2.getValue() - 63.3968)*10000)) < 1);
}

void unit_Model_add(void){
    System s1;
    ExponentialFlow f1("f1", NULL, NULL);

    Model model;
    model.add(&s1);
    model.add(&f1);

    Model::flowIterator itFlow = model.beginFlow();
    Model::systemIterator itSystem = model.beginSystem();

    assert((*itFlow) ==  &f1);
    assert((*itSystem) ==  &s1);
}

//System vector
void unit_Model_beginSystem(void){
    System s1;
    Model model;
    model.add(&s1);

    Model::systemIterator itSystem = model.beginSystem();
    assert((*itSystem) ==  &s1);
}
void unit_Model_endSystem(void){
    System s1;
    System s2;
    Model model;
    model.add(&s1);
    model.add(&s2);

    Model::systemIterator itSystem = model.endSystem();
    itSystem--;
    assert((*itSystem) ==  &s2);
}

//Flow vector
void unit_Model_beginFlow(void){
    ExponentialFlow f1("f1", NULL, NULL);
    Model model;
    model.add(&f1);

    Model::flowIterator itFlow = model.beginFlow();
    assert((*itFlow) ==  &f1);
}
void unit_Model_endFlow(void){
    ExponentialFlow f1("f1", NULL, NULL);
    ExponentialFlow f2("f2", NULL, NULL);
    Model model;
    model.add(&f1);
    model.add(&f2);

    Model::flowIterator itFlow = model.endFlow();
    itFlow--;
    assert((*itFlow) ==  &f2);
}

void run_unit_tests_Model( void ){
    unit_Model_constructor();
    unit_Model_destructor();
    unit_Model_run();
    unit_Model_add();
    unit_Model_beginSystem();
    unit_Model_endSystem();
    unit_Model_beginFlow();
    unit_Model_endFlow();
}
