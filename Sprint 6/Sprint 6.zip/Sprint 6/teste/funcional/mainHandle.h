#ifndef MAIN_HANDLE
#define MAIN_HANDLE

void teste();

#endif