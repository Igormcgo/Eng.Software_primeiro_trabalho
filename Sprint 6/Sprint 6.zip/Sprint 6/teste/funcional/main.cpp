#ifndef  MAIN_FUNCIONAL_TESTS
#define MAIN_FUNCIONAL_TESTS
#include "funcional_tests.h"
#include "mainHandle.h"
#include <iostream>

int main(){

    exponentialFuncionalTest();

    logisticalFuncionalTest();

    complexFuncionalTest();

    teste();

    std::cout<<"OK";

    return 0;
}
#endif