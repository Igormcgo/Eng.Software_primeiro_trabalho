#include <assert.h>
#include "unit_tests.h"

  void run_unit_tests_globals( void ){}