var searchData=
[
  ['systems_0',['systems',['../class_model_imp.html#a13a643b3800bebb8b5b7bf8ab55b73c2',1,'ModelImp']]]
];
